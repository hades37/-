# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'test.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import pymssql
from Student_MainWindow_ui import Ui_MainWindow
import Teacher_MainWindow
import Administrator_ui
import Administrator
from threading import Thread
def Student_Show(Info,conn):
    app = QtWidgets.QApplication(sys.argv)
    MainWindows = QtWidgets.QMainWindow()
    ui = Ui_MainWindow(conn, Info, MainWindows)
    sys.exit(app.exec_())
def Teacher_Show(Info,conn):
    app = QtWidgets.QApplication(sys.argv)
    MainWindows = QtWidgets.QMainWindow()
    ui = Teacher_MainWindow.Ui_MainWindow(Info, conn, MainWindows)
    sys.exit(app.exec_())
def Administator_Show(Info,conn):
    app = QtWidgets.QApplication(sys.argv)
    MainWindows = QtWidgets.QMainWindow()
    ui = Administrator_ui.Ui_MainWindow(MainWindows, conn,Info)
    sys.exit(app.exec_())
class Ui_MainWindows(QtWidgets.QMainWindow):
    def __init__(self,conn,MainWindow):
        self.term=1
        super().__init__()
        self.MainWindow=MainWindow
        self.cur=conn.cursor()
        self.conn=conn
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(480, 436)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(150, 150, 201, 81))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.lineEdit_Account = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_Account.setObjectName("lineEdit_Account")
        self.verticalLayout.addWidget(self.lineEdit_Account)
        self.lineEdit_Passwd = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_Passwd.setObjectName("lineEdit_Passwd")
        self.verticalLayout.addWidget(self.lineEdit_Passwd)
        self.label_Account = QtWidgets.QLabel(self.centralwidget)
        self.label_Account.setGeometry(QtCore.QRect(70, 160, 72, 15))
        self.label_Account.setObjectName("label_Account")
        self.label_Passwd = QtWidgets.QLabel(self.centralwidget)
        self.label_Passwd.setGeometry(QtCore.QRect(70, 200, 72, 15))
        self.label_Passwd.setObjectName("label_Passwd")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(150, 240, 93, 28))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(260, 240, 93, 28))
        self.pushButton_2.setObjectName("pushButton_2")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 480, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.pushButton.clicked.connect(self.Login)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "登录"))
        self.label_Account.setText(_translate("MainWindow", "     账户"))
        self.label_Passwd.setText(_translate("MainWindow", "     密码"))
        self.pushButton.setText(_translate("MainWindow", "登录"))
        self.pushButton_2.setText(_translate("MainWindow", "取消"))
    def Login(self):
        self.Account=self.lineEdit_Account.text()
        self.Passwd=self.lineEdit_Passwd.text()
        self.cur.execute(r"select * from tab_account")
        CountInfo=self.cur.fetchall()
        flag=0
        index=0
        print(CountInfo)
        for i in CountInfo:
            if self.Account==i[0].strip() and self.Passwd==i[1].strip():
                flag=1
                index=i
        print(index)
        if(flag and index[2].strip()=="学生"):
           Student_Main=Thread(target=Student_Show,args=((self.Account,self.term,self.Passwd),self.conn))
           MainWindow.hide()
           Student_Main.start()

        elif(flag and index[2].strip()=="教师"):
            Teacher_Main=Thread(target=Teacher_Show,args=((self.Account,self.term,self.Passwd),self.conn))
            MainWindow.hide()
            Teacher_Main.start()
        elif(flag and index[2]=="管理员"):
            Administrator_Main=Thread(target=Administator_Show,args=((self.Account,index[2],self.Passwd),self.conn))
            MainWindow.hide()
            Administrator_Main.start()

        else:
            reply = QtWidgets.QMessageBox.warning(self, "登录失败", "用户名或密码错误！", QtWidgets.QMessageBox.Yes)
            self.lineEdit_Account.clear()
            self.lineEdit_Passwd.clear()


if __name__ == '__main__':
    conn = pymssql.connect(host='127.0.0.1', user='sa', password='19981111', database='StudentManage',charset='utf8')
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindows(conn,MainWindow)
    ui.setupUi(MainWindow)
    MainWindow.setObjectName("Windows")
    MainWindow.setStyleSheet("#Windows{border-image:url(./image/SQL.jpg);}")
    MainWindow.show()
    sys.exit(app.exec_())

