# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Course.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import Password
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import pymssql
class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self,Info,conn,Mainwindow):
        super().__init__()
        self.conn=conn
        self.cur=conn.cursor()
        self.Info=Info
        Mainwindow.show()
        self.setupUi(Mainwindow)
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1110, 534)
        MainWindow.setStyleSheet("#MainWindow{border-image:url(./image/datas.jpg);}")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")


        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1110, 26))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        self.menu_2 = QtWidgets.QMenu(self.menubar)
        self.menu_2.setObjectName("menu_2")
        self.menu_3 = QtWidgets.QMenu(self.menubar)
        self.menu_3.setObjectName("menu_3")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.action = QtWidgets.QAction(MainWindow)
        self.action.setObjectName("action")
        self.action_2 = QtWidgets.QAction(MainWindow)
        self.action_2.setObjectName("action_2")
        self.action_D=QtWidgets.QAction(MainWindow)
        self.action_D.setObjectName("action_D")
        self.action_3 = QtWidgets.QAction(MainWindow)
        self.action_3.setObjectName("action_3")
        self.action_4 = QtWidgets.QAction(MainWindow)
        self.action_4.setObjectName("action_4")
        self.action_5 = QtWidgets.QAction(MainWindow)
        self.action_5.setObjectName("action_5")
        self.action_6 = QtWidgets.QAction(MainWindow)
        self.action_6.setObjectName("action_6")
        self.action_7 = QtWidgets.QAction(MainWindow)
        self.action_7.setObjectName("action_7")
        self.action_8=QtWidgets.QAction(MainWindow)
        self.action_8.setObjectName("action_8")
        self.menu.addAction(self.action)
        self.menu.addAction(self.action_2)
        self.menu.addAction(self.action_D)
        self.menu.addAction(self.action_3)
        self.menu.addAction(self.action_8)
        self.menu_2.addAction(self.action_4)
        self.menu_2.addAction(self.action_5)
        self.menu_3.addAction(self.action_6)
        self.menu_3.addAction(self.action_7)
        self.menubar.addAction(self.menu.menuAction())
        self.menubar.addAction(self.menu_2.menuAction())
        self.menubar.addAction(self.menu_3.menuAction())

        self.retranslateUi(MainWindow)
        self.action.triggered.connect(self.Action_slot)
        self.action_2.triggered.connect(self.Course_Edit)
        self.action_D.triggered.connect(self.Course_Delete_Slote)
        self.action_3.triggered.connect(self.action_Query)
        self.action_5.triggered.connect(self.Action_Score_slot)
        self.action_4.triggered.connect(self.Score_Change_slot)
        self.action_6.triggered.connect(self.Action_Id)
        self.action_7.triggered.connect(self.Passwd_Chage)
        self.action_8.triggered.connect(self.Action_8_slot)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "教师"))
        self.menu.setTitle(_translate("MainWindow", "课程管理"))
        self.menu_2.setTitle(_translate("MainWindow", "课程成绩管理"))
        self.menu_3.setTitle(_translate("MainWindow", "个人信息管理"))
        self.action.setText(_translate("MainWindow", "课程发布"))
        self.action_2.setText(_translate("MainWindow", "课程修改"))
        self.action_D.setText(_translate("MainWindwo","课程删除"))
        self.action_3.setText(_translate("MainWindow", "课程查询"))
        self.action_4.setText(_translate("MainWindow", "成绩修改"))
        self.action_5.setText(_translate("MainWindow", "成绩统计"))
        self.action_6.setText(_translate("MainWindow", "资料修改"))
        self.action_7.setText(_translate("MainWindow", "密码修改"))
        self.action_8.setText(_translate("MainWindow","学生选课情况"))
    def Action_8_slot(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from View_Score where tno ='{}'".format(self.Info[0]))
        Courserecord = self.cur.fetchall()
        print(Courserecord)
        self.row_R = len(Courserecord)
        self.tableWidget.setColumnCount(10)
        self.tableWidget.setRowCount(self.row_R)
        for i in range(self.row_R):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(10):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "学号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "姓名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "教师工号"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师名"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "学期"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "学院号"))
        item = self.tableWidget.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "成绩"))


        for i in range(self.row_R):
            for j in range(10):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(Courserecord[i][j])))

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)

    def Action_slot(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(8)
        self.tableWidget.setRowCount(5)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(7, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)


        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton_submit = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_submit.setObjectName("pushButton_submit")
        self.verticalLayout.addWidget(self.pushButton_submit)
        self.pushButton_cancel = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_cancel.setObjectName("pushButton_cancel")
        self.verticalLayout.addWidget(self.pushButton_cancel)

        _translate = QtCore.QCoreApplication.translate
        item = self.tableWidget.verticalHeaderItem(0)
        item.setText(_translate("MainWindow", "1"))
        item = self.tableWidget.verticalHeaderItem(1)
        item.setText(_translate("MainWindow", "2"))
        item = self.tableWidget.verticalHeaderItem(2)
        item.setText(_translate("MainWindow", "3"))
        item = self.tableWidget.verticalHeaderItem(3)
        item.setText(_translate("MainWindow", "4"))
        item = self.tableWidget.verticalHeaderItem(4)
        item.setText(_translate("MainWindow", "5"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "开课学期"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "课程学分"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师号"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "专业号"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程容量"))

        for i in range(5):
            for j in range(8):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", ""))

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.pushButton_submit.setText(_translate("MainWindow", "提交"))
        self.pushButton_cancel.setText(_translate("MainWindow", "取消"))
        self.pushButton_submit.clicked.connect(self.Submit_slot)
        self.pushButton_cancel.clicked.connect(self.Cancel_Slot)
    def Submit_slot(self):
        self._translate = QtCore.QCoreApplication.translate
        Col_Count=self.tableWidget.columnCount()
        Row_Count=self.tableWidget.rowCount()
        print(Col_Count,Row_Count)
        CoreseC=[]
        for i in range(Row_Count):
            Cour_data = []
            if self.tableWidget.item(i,0).text():
                print(i)
                print((self.tableWidget.item(i,0).text())==None)
                for j in range(Col_Count):
                    print(j)
                    Cour_data.append(self.tableWidget.item(i,j).text())
                CoreseC.append(Cour_data)

            else:continue
        flag=0#记录是否触发警告
        for i in CoreseC:
            print(type(int(i[4])))
            if int(i[3])<1 or int(i[3])>8 or int(i[3])<self.Info[1]:
                tips=QtWidgets.QMessageBox.warning(self,"提示","学期不正确",QtWidgets.QMessageBox.NoButton)
                flag=1
            elif int(i[4])<0.5 or int(i[4])>5:
                tips = QtWidgets.QMessageBox.warning(self, "提示", "学分不正确", QtWidgets.QMessageBox.NoButton)
                flag=1
            elif i[0]=="":
                tips = QtWidgets.QMessageBox.warning(self, "提示", "课程号不可空", QtWidgets.QMessageBox.NoButton)
                flag=1
            else:
                self.cur.execute(r"INSERT INTO tab_courses(cno,cname,ctype,term,credit,tno,majorno,remain) VALUES('{}','{}','{}',{},{},'{}','{}',{})".format(i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7]))
                self.conn.commit()
        if not flag:
            tips=QtWidgets.QMessageBox.information(self,"提示","课程发布成功",QtWidgets.QMessageBox.NoButton)
        else:
            self.Action_slot()
        for i in range(5):
            for j in range(8):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(self._translate("MainWindow", ""))
    def Cancel_Slot(self):
        Tips=QtWidgets.QMessageBox.information(self,"提示","已处于可编辑状态！",QtWidgets.QMessageBox.NoButton)

    def Course_Edit(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from tab_courses where tno ='{}'".format(self.Info[0]))
        Courserecord =self.cur.fetchall()
        self.row_R=len(Courserecord)
        self.tableWidget.setColumnCount(8)
        self.tableWidget.setRowCount(self.row_R+5)
        for i in range(self.row_R+5):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(8):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton_submit = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_submit.setObjectName("pushButton_submit")
        self.verticalLayout.addWidget(self.pushButton_submit)
        self.pushButton_cancel = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_cancel.setObjectName("pushButton_cancel")
        self.verticalLayout.addWidget(self.pushButton_cancel)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R+5):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d"%i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "开课学期"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "课程学分"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师号"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "专业号"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程容量"))

        for i in range(self.row_R):
            for j in range(8):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow",str(Courserecord[i][j])))

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.pushButton_submit.setText(_translate("MainWindow", "提交"))
        self.pushButton_cancel.setText(_translate("MainWindow", "取消"))
        self.pushButton_submit.clicked.connect(self.Submit_slot_Edit)
        self.pushButton_cancel.clicked.connect(self.Cancel_Slot)
    def Score_Change_slot(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from tab_Score where tno ='{}'".format(self.Info[0]))
        Courserecord =self.cur.fetchall()
        self.row_R=len(Courserecord)
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(self.row_R+5)
        for i in range(self.row_R+5):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(4):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton_submit = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_submit.setObjectName("pushButton_submit")
        self.verticalLayout.addWidget(self.pushButton_submit)
        self.pushButton_cancel = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_cancel.setObjectName("pushButton_cancel")
        self.verticalLayout.addWidget(self.pushButton_cancel)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R+5):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d"%i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "学号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "教师号"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "成绩"))

        for i in range(self.row_R):
            for j in range(4):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow",str(Courserecord[i][j])))
        for i in range(self.row_R):
            for j in range(3):
                self.tableWidget.item(i,j).setFlags(QtCore.Qt.ItemIsEnabled)

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.pushButton_submit.setText(_translate("MainWindow", "提交"))
        self.pushButton_cancel.setText(_translate("MainWindow", "取消"))
        self.pushButton_submit.clicked.connect(self.Score_Chage_Submit)
        self.pushButton_cancel.clicked.connect(self.Cancel_Slot)
    def Score_Chage_Submit(self):
        self._translate = QtCore.QCoreApplication.translate
        Col_Count = self.tableWidget.columnCount()
        Row_Count = self.tableWidget.rowCount()
        CoreseC = []
        for i in range(self.row_R):
            Cour_data = []
            Cour_data.append((self.tableWidget.item(i, 0).text(),self.tableWidget.item(i,1).text(),self.tableWidget.item(i,2).text(),self.tableWidget.item(i,3).text()))
            CoreseC.append(Cour_data)
        flag=0
        for i in CoreseC:
            if int(i[0][3])<0 or int(i[0][3])>100:
                tips = QtWidgets.QMessageBox.warning(self, "提示", "成绩范围在0-100！", QtWidgets.QMessageBox.NoButton)
                flag=1

            else:
                self.cur.execute(r"update tab_Score set score={} where cno='{}'and tno='{}'and sno='{}'".format(i[0][3],i[0][1],i[0][2],i[0][0]))
                self.conn.commit()
        if not flag:
            tips = QtWidgets.QMessageBox.information(self, "提示", "修改成功", QtWidgets.QMessageBox.NoButton)
        else:
            self.Score_Change_slot()
    def Submit_slot_Edit(self):
        self._translate = QtCore.QCoreApplication.translate
        Col_Count = self.tableWidget.columnCount()
        Row_Count = self.tableWidget.rowCount()
        CoreseC = []
        for i in range(self.row_R):
            Cour_data = []
            for j in range(Col_Count):
                Cour_data.append(self.tableWidget.item(i, j).text())
            CoreseC.append(Cour_data)
            print(Cour_data)
        tips = QtWidgets.QMessageBox.warning(self, "提示", "课程号修改需删除原有课程", QtWidgets.QMessageBox.NoButton)
        for i in CoreseC:
            print("True")
            if int(i[4]) < 0.5 or int(i[4]) > 5:
                tips = QtWidgets.QMessageBox.warning(self, "提示", "学分不正确", QtWidgets.QMessageBox.NoButton)
            elif i[0]=="":
                tips = QtWidgets.QMessageBox.warning(self, "提示", "课程号不可空", QtWidgets.QMessageBox.NoButton)

            else:
                try:
                    self.cur.execute(r"update tab_courses set cno= '{}',cname='{}',ctype='{}',term={},credit={},tno='{}',majorno='{}',remain={} where cno='{}'".format(i[0], i[1], i[2], i[3], i[4], i[5], i[6].strip(), i[7],i[0]))
                    self.conn.commit()
                except:
                    tips = QtWidgets.QMessageBox.warning(self, "提示", "课程号修改需删除原有课程", QtWidgets.QMessageBox.NoButton)



        tips = QtWidgets.QMessageBox.information(self, "提示", "课程修改成功", QtWidgets.QMessageBox.NoButton)
        for i in range(self.row_R):
            for j in range(8):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(self._translate("MainWindow", ""))

    def Course_Delete_Slote(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from tab_courses where tno ='{}'".format(self.Info[0]))
        Courserecord = self.cur.fetchall()
        self.row_R = len(Courserecord)
        self.tableWidget.setColumnCount(9)
        self.tableWidget.setRowCount(self.row_R + 5)
        for i in range(self.row_R + 5):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(9):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton_submit = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_submit.setObjectName("pushButton_submit")
        self.verticalLayout.addWidget(self.pushButton_submit)
        self.pushButton_cancel = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_cancel.setObjectName("pushButton_cancel")
        self.verticalLayout.addWidget(self.pushButton_cancel)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R + 5):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "开课学期"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "课程学分"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师号"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "专业号"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程容量"))

        for i in range(self.row_R):
            for j in range(9):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                if j==8:
                    cb = QtWidgets.QTableWidgetItem()
                    cb.setCheckState(QtCore.Qt.Unchecked)
                    self.tableWidget.setItem(i, j, cb)
                else:
                    item.setText(_translate("MainWindow", str(Courserecord[i][j])))

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.pushButton_submit.setText(_translate("MainWindow", "提交"))
        self.pushButton_cancel.setText(_translate("MainWindow", "取消"))
        self.pushButton_submit.clicked.connect(self.Action_D_Access_slot)
        self.pushButton_cancel.clicked.connect(self.Action_D_Slots)
    def Action_D_Access_slot(self):
        self.Checkstate = []
        print(self.row_R)
        for i in range(self.row_R):
            if self.tableWidget.item(i,8 ).checkState() == QtCore.Qt.Checked:
                CNO= (self.tableWidget.item(i, 0).text())
                self.Checkstate.append(CNO)
        for i in self.Checkstate:
            print(r"DELETE FROM tab_courses WHERE  cno='{}'".format(i))
            self.cur.execute(r"DELETE FROM tab_courses WHERE  cno='{}'".format(i))
            self.conn.commit()
        tips = QtWidgets.QMessageBox.information(self, "提示", "删除成功", QtWidgets.QMessageBox.NoButton)
        self.Course_Delete_Slote()
    def Action_D_Slots(self):
        print(self.row_R)
        for i in range(self.row_R):
            if self.tableWidget.item(i,8).checkState() == QtCore.Qt.Checked:
                self.tableWidget.item(i,8).setCheckState(QtCore.Qt.Unchecked)
    def action_Query(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from tab_courses where tno ='{}'".format(self.Info[0]))
        Courserecord = self.cur.fetchall()
        self.row_R = len(Courserecord)
        self.tableWidget.setColumnCount(8)
        self.tableWidget.setRowCount(self.row_R + 5)
        for i in range(self.row_R + 5):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(8):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton_submit = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_submit.setObjectName("pushButton_submit")
        self.verticalLayout.addWidget(self.pushButton_submit)
        self.pushButton_cancel = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_cancel.setObjectName("pushButton_cancel")
        self.verticalLayout.addWidget(self.pushButton_cancel)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R + 5):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "开课学期"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "课程学分"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师号"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "专业号"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程容量"))

        for i in range(self.row_R):
            for j in range(8):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(Courserecord[i][j])))

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
    def Action_Score_slot(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from View_Score where tno ='{}'and score >0".format(self.Info[0]))
        Courserecord = self.cur.fetchall()
        print(Courserecord)
        self.row_R = len(Courserecord)
        self.tableWidget.setColumnCount(10)
        self.tableWidget.setRowCount(self.row_R)
        for i in range(self.row_R):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(10):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "学号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "姓名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "教师工号"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师名"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "学期"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "学院号"))
        item = self.tableWidget.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "成绩"))


        for i in range(self.row_R):
            for j in range(10):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(Courserecord[i][j])))

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
    def Action_Id(self):
        #修改自身的资料
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from tab_teacher where tno ='{}'".format(self.Info[0]))
        self.Information= self.cur.fetchall()
        self.row_R = len(self.Information)
        self.tableWidget.setColumnCount(6)
        self.tableWidget.setRowCount(self.row_R+1)
        for i in range(self.row_R + 1):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(6):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton_submit = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_submit.setObjectName("pushButton_submit")
        self.verticalLayout.addWidget(self.pushButton_submit)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R + 1):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "教师工号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "教师姓名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "教师邮箱"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "性别"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "职称"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "学院号"))

        for i in range(self.row_R):
            for j in range(6):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(self.Information[i][j])))
        for i in range(self.row_R):
            self.tableWidget.item(i, 0).setFlags(QtCore.Qt.ItemIsEnabled)
            self.tableWidget.item(i, 4).setFlags(QtCore.Qt.ItemIsEnabled)
            self.tableWidget.item(i, 5).setFlags(QtCore.Qt.ItemIsEnabled)


        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.pushButton_submit.setText(_translate("MainWindow", "提交"))
        self.pushButton_submit.clicked.connect(self.Submit_Id)
    def Submit_Id(self):
        Information=[]
        for i in range(self.row_R):
            for j in range(6):
                Information.append(self.tableWidget.item(i,j).text())
        self.cur.execute(r"update tab_teacher set tname='{}',tsex='{}',temail='{}' where tno='{}'".format(Information[1],Information[3],Information[2],Information[0].strip()))
        self.conn.commit()
        tips = QtWidgets.QMessageBox.information(self, "提示", "修改成功", QtWidgets.QMessageBox.NoButton)
        self.Action_Id()
    def Passwd_Chage(self):
        try:
            self.pushButton_submit.deleteLater()
            self.pushButton_cancel.deleteLater()
        except:
            print("")
        try:
            self.tableWidget.deleteLater()
        except:
            print("")
        self.ui = Password.Ui_Dialog(self.conn, self.Info)
        self.ui.show()

if __name__=='__main__':
    conn = pymssql.connect(host='127.0.0.1', user='sa', password='19981111', database='StudentManage', charset='utf8')
    Info=("XY010001",1,"XY0101")
    App = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    Ui = Ui_MainWindow(Info,conn,MainWindow)
    App.exec_()

