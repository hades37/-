# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Manage.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import PassWdCg
from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import pymssql
import Password
class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self,conn,Info,MainWindow):
        super().__init__()
        self.cur = conn.cursor()
        self.conn=conn
        self.Info=Info
        self.setupUi(MainWindow)
        self.MainWindws=MainWindow
        MainWindow.setObjectName("Windows")
        MainWindow.setStyleSheet("#Windows{border-image:url(./image/sun.jpg);}")
        MainWindow.show()
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1473, 787)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_stduent_info = QtWidgets.QLabel(self.centralwidget)
        self.label_stduent_info.setObjectName("label_stduent_info")
        self.verticalLayout_2.addWidget(self.label_stduent_info)
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setSizeConstraint(QtWidgets.QLayout.SetDefaultConstraint)
        self.verticalLayout.setObjectName("verticalLayout")

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1473, 26))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        self.menu_2 = QtWidgets.QMenu(self.menubar)
        self.menu_2.setObjectName("menu_2")
        self.menu_3 = QtWidgets.QMenu(self.menubar)
        self.menu_3.setObjectName("menu_3")
        self.menu_4 = QtWidgets.QMenu(self.menubar)
        self.menu_4.setObjectName("menu_4")
        self.menu_5 = QtWidgets.QMenu(self.menubar)
        self.menu_5.setObjectName("menu_5")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.action = QtWidgets.QAction(MainWindow)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("C:/Users/Hades/Downloads/fugue-icons-master/icons/abacus.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.action.setIcon(icon)
        self.action.setObjectName("action")
        self.action_2 = QtWidgets.QAction(MainWindow)
        self.action_2.setObjectName("action_2")
        self.action_3 = QtWidgets.QAction(MainWindow)
        self.action_3.setObjectName("action_3")
        self.action_4 = QtWidgets.QAction(MainWindow)
        self.action_4.setObjectName("action_4")
        self.action_5 = QtWidgets.QAction(MainWindow)
        self.action_5.setObjectName("action_5")
        self.action_6 = QtWidgets.QAction(MainWindow)
        self.action_6.setObjectName("action_6")
        self.action_7 = QtWidgets.QAction(MainWindow)
        self.action_7.setObjectName("action_7")
        self.action_8 = QtWidgets.QAction(MainWindow)
        self.action_8.setObjectName("action_8")
        self.menu.addAction(self.action)
        self.menu.addAction(self.action_2)
        self.menu.addAction(self.action_3)
        self.menu_2.addAction(self.action_4)
        self.menu_2.addAction(self.action_5)
        self.menu_3.addAction(self.action_6)
        self.menu_4.addAction(self.action_7)
        self.menu_5.addAction(self.action_8)
        self.menubar.addAction(self.menu.menuAction())
        self.menubar.addAction(self.menu_2.menuAction())
        self.menubar.addAction(self.menu_3.menuAction())
        self.menubar.addAction(self.menu_4.menuAction())
        self.menubar.addAction(self.menu_5.menuAction())

        self.retranslateUi(MainWindow)
        self.action.triggered.connect(self.Compulsory)
        self.action_2.triggered.connect(self.Elective)
        self.action_3.triggered.connect(self.Withdrawal)
        self.action_4.triggered.connect(self.Score_Query)
        self.action_5.triggered.connect(self.Score_history)
        self.action_6.triggered.connect(self.GraduateDesign)
        self.action_7.triggered.connect(self.Action7_slot)
        self.action_8.triggered.connect(self.Action8_slot)

        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        self._translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(self._translate("MainWindow", "学生"))

        self.menu.setTitle(self._translate("MainWindow", "               学生选课                 "))
        self.menu_2.setTitle(self._translate("MainWindow", "                 成绩查询                   "))
        self.menu_3.setTitle(self._translate("MainWindow", "           毕业设计        "))
        self.menu_4.setTitle(self._translate("MainWindow", "       补考查询       "))
        self.menu_5.setTitle(self._translate("MainWindow", "       账户管理      "))
        self.action.setText(self._translate("MainWindow", "专业必修课程"))
        self.action_2.setText(self._translate("MainWindow", "专业选修课程"))
        self.action_3.setText(self._translate("MainWindow", "         退选"))
        self.action_4.setText(self._translate("MainWindow", "本学期成绩查询"))
        self.action_5.setText(self._translate("MainWindow", "历史成绩查询"))
        self.action_6.setText(self._translate("MainWindow", "毕设选题"))
        self.action_7.setText(self._translate("MainWindow", "补考查询"))
        self.action_8.setText(self._translate("MainWindow", "密码修改"))
    def Compulsory(self):
        try:
            self.tableWidget.deleteLater()
            self.tableWidget_2.deleteLater()
            self.label_2.deleteLater()
        except:
            pass
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            pass
        finally:
            self.cur.execute(r"select * from tab_courses as a where a.cno not in (select cno from tab_Score where sno='{}') AND ctype='必修'".format(self.Info[0]))
            Rows = self.cur.fetchall()
            Row = len(Rows)
            Vol = len(Rows[0])+1
            self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
            self.tableWidget.setObjectName("tableWidget")
            self.tableWidget.setColumnCount(Vol)
            self.tableWidget.setRowCount(Row)
            for i in range(Vol):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setVerticalHeaderItem(i, item)
            for i in range(Row):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setHorizontalHeaderItem(i, item)
            self.verticalLayout.addWidget(self.tableWidget)
            self.verticalLayout_2.addLayout(self.verticalLayout)
            self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
            self.pushButton_2.setObjectName("pushButton_2")
            self.verticalLayout_2.addWidget(self.pushButton_2)
            self.pushButton = QtWidgets.QPushButton(self.centralwidget)
            self.pushButton.setObjectName("pushButton")
            self.verticalLayout_2.addWidget(self.pushButton)
            self.label_2 = QtWidgets.QLabel(self.centralwidget)
            self.label_2.setObjectName("label_2")
            self._translate = QtCore.QCoreApplication.translate
            self.label_stduent_info.setText(self._translate("MainWindow", "网络工程(2018-2019)上学期16272411班级"))
            self.label.setText(self._translate("MainWindow", "可选课程"))
            item = self.tableWidget.horizontalHeaderItem(0)
            item.setText(self._translate("MainWindow", "课程号"))
            item = self.tableWidget.horizontalHeaderItem(1)
            item.setText(self._translate("MainWindow", "课程名"))
            item = self.tableWidget.horizontalHeaderItem(2)
            item.setText(self._translate("MainWindow", "课程类型"))
            item = self.tableWidget.horizontalHeaderItem(3)
            item.setText(self._translate("MainWindow", "开课学期"))
            item = self.tableWidget.horizontalHeaderItem(4)
            item.setText(self._translate("MainWindow", "课程学分"))
            item = self.tableWidget.horizontalHeaderItem(5)
            item.setText(self._translate("MainWindow", "任课教师"))
            item = self.tableWidget.horizontalHeaderItem(6)
            item.setText(self._translate("MainWindow", "课程专业"))
            item = self.tableWidget.horizontalHeaderItem(7)
            item.setText(self._translate("MainWindow", "课程余量"))
            __sortingEnabled = self.tableWidget.isSortingEnabled()
            self.tableWidget.setSortingEnabled(False)

            for i in range(Row):
                for j in range(Vol):
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget.setItem(i, j, item)
                    item = self.tableWidget.item(i, j)
                    if j==(Vol-1):
                        cb = QtWidgets.QTableWidgetItem()
                        cb.setCheckState(QtCore.Qt.Unchecked)
                        self.tableWidget.setItem(i,j,cb)

                    else:item.setText(self._translate("MainWindow", str(Rows[i][j])))
            self.tableWidget.setSortingEnabled(__sortingEnabled)
            self.pushButton_2.setText(self._translate("MainWindow", "提交"))
            self.pushButton.setText(self._translate("MainWindow", "取消"))
            self.pushButton_2.clicked.connect(self.Submit)
            self.pushButton.clicked.connect(self.Cancel)
            self.label_2 = QtWidgets.QLabel(self.centralwidget)
            self.label_2.setObjectName("label_2")
            self.verticalLayout_2.addWidget(self.label_2)
            self.cur.execute(r"select * from tab_courses as a where a.cno in (select cno from tab_Score where sno='{}') ".format(self.Info[0]))
            Rows = self.cur.fetchall()
            Row = len(Rows)
            self.Record =Row  # 记录表格中的记录发生改变个数
            Vol = len(Rows[0]) - 1
            self.tableWidget_2 = QtWidgets.QTableWidget(self.centralwidget)
            self.tableWidget_2.setObjectName("tableWidget_2")

            self.tableWidget_2.setColumnCount(Vol)
            self.tableWidget_2.setRowCount(Row+10)
            item = QtWidgets.QTableWidgetItem()
            for i in range((Row+10)):
                self.tableWidget_2.setVerticalHeaderItem(i, item)
                item = QtWidgets.QTableWidgetItem()
            for i in range(Vol):
                self.tableWidget_2.setHorizontalHeaderItem(i, item)
                item = QtWidgets.QTableWidgetItem()
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget_2.setItem(0, 0, item)
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget_2.setItem(1, 0, item)
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget_2.setItem(2, 1, item)
            self.verticalLayout_2.addWidget(self.tableWidget_2)
            #MainWindow.setCentralWidget(self.centralwidget)
            self.label_2.setText(self._translate("MainWindow", "已选课程"))

            for i in range(Row):
                item = self.tableWidget_2.verticalHeaderItem(i)
                item.setText(self._translate("MainWindow", "%d"%i))

            item = self.tableWidget_2.horizontalHeaderItem(0)
            item.setText(self._translate("MainWindow", "课程号"))
            item = self.tableWidget_2.horizontalHeaderItem(1)
            item.setText(self._translate("MainWindow", "课程名"))
            item = self.tableWidget_2.horizontalHeaderItem(2)
            item.setText(self._translate("MainWindow", "课程类型"))
            item = self.tableWidget_2.horizontalHeaderItem(3)
            item.setText(self._translate("MainWindow", "开课学期"))
            item = self.tableWidget_2.horizontalHeaderItem(4)
            item.setText(self._translate("MainWindow", "课程学分"))
            item = self.tableWidget_2.horizontalHeaderItem(5)
            item.setText(self._translate("MainWindow", "任课教师"))
            item = self.tableWidget_2.horizontalHeaderItem(6)
            item.setText(self._translate("MainWindow", "课程专业"))
            __sortingEnabled = self.tableWidget_2.isSortingEnabled()
            self.tableWidget_2.setSortingEnabled(False)
            self.tableWidget.setSortingEnabled(__sortingEnabled)
            for i in range(Row):
                for j in range(Vol):
                    print(Rows[i][j])
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget_2.setItem(i, j, item)
                    item = self.tableWidget_2.item(i, j)
                    item.setText(self._translate("MainWindow", str(Rows[i][j])))
            self.tableWidget.setSortingEnabled(__sortingEnabled)

    def Submit(self):
        self.Checkstate=[]
        for i in range(self.tableWidget.rowCount()):
            if self.tableWidget.item(i, 8).checkState() ==QtCore.Qt.Checked:
                CNO_TNO=(self.tableWidget.item(i,0).text(),self.tableWidget.item(i,5).text())
                self.Checkstate.append(CNO_TNO)
        print(self.Checkstate)
        for i in self.Checkstate:
            self.cur.execute(r"INSERT INTO tab_Score(sno,cno,tno,score) VALUES('{}','{}','{}',{})".format(self.Info[0],i[0],i[1],"NULL"))
            self.cur.execute(r"UPDATE tab_courses SET remain=remain-1 WHERE cno='{}'".format(i[0]))
            self.conn.commit()
        self.Compulsory()
    def Elective(self):
        try:
            self.tableWidget.deleteLater()
            self.tableWidget_2.deleteLater()
            self.label_2.deleteLater()
        except:
            print("666")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("666")
        finally:
            self.cur.execute(r"select * from tab_courses as a where a.cno not in (select cno from tab_Score where sno='{}') AND ctype='选修'".format(self.Info[0]))
            Rows = self.cur.fetchall()
            Row = len(Rows)
            Vol = len(Rows[0]) + 1
            print("finish")
            self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
            self.tableWidget.setObjectName("tableWidget")
            self.tableWidget.setColumnCount(Vol)
            self.tableWidget.setRowCount(Row)
            for i in range(Vol):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setVerticalHeaderItem(i, item)
            for i in range(Row):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setHorizontalHeaderItem(i, item)

            self.verticalLayout.addWidget(self.tableWidget)
            self.verticalLayout_2.addLayout(self.verticalLayout)
            self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
            self.pushButton_2.setObjectName("pushButton_2")
            self.verticalLayout_2.addWidget(self.pushButton_2)
            self.pushButton = QtWidgets.QPushButton(self.centralwidget)
            self.pushButton.setObjectName("pushButton")
            self.verticalLayout_2.addWidget(self.pushButton)
            self.label_2 = QtWidgets.QLabel(self.centralwidget)
            self.label_2.setObjectName("label_2")

            self._translate = QtCore.QCoreApplication.translate
            #MainWindow.setWindowTitle(self._translate("MainWindow", "MainWindow"))
            self.label_stduent_info.setText(self._translate("MainWindow", "网络工程(2018-2019)上学期16272411班级"))
            self.label.setText(self._translate("MainWindow", "可选课程"))

            item = self.tableWidget.horizontalHeaderItem(0)
            item.setText(self._translate("MainWindow", "课程号"))
            item = self.tableWidget.horizontalHeaderItem(1)
            item.setText(self._translate("MainWindow", "课程名"))
            item = self.tableWidget.horizontalHeaderItem(2)
            item.setText(self._translate("MainWindow", "课程类型"))
            item = self.tableWidget.horizontalHeaderItem(3)
            item.setText(self._translate("MainWindow", "开课学期"))
            item = self.tableWidget.horizontalHeaderItem(4)
            item.setText(self._translate("MainWindow", "课程学分"))
            item = self.tableWidget.horizontalHeaderItem(5)
            item.setText(self._translate("MainWindow", "任课教师"))
            item = self.tableWidget.horizontalHeaderItem(6)
            item.setText(self._translate("MainWindow", "课程专业"))
            item = self.tableWidget.horizontalHeaderItem(7)
            item.setText(self._translate("MainWindow", "课程余量"))
            __sortingEnabled = self.tableWidget.isSortingEnabled()
            self.tableWidget.setSortingEnabled(False)

            for i in range(Row):
                for j in range(Vol):
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget.setItem(i, j, item)
                    item = self.tableWidget.item(i, j)
                    if j == (Vol - 1):
                        cb = QtWidgets.QTableWidgetItem()
                        cb.setCheckState(QtCore.Qt.Unchecked)
                        self.tableWidget.setItem(i, j, cb)

                    else:
                        item.setText(self._translate("MainWindow", str(Rows[i][j])))

            self.tableWidget.setSortingEnabled(__sortingEnabled)
            self.pushButton_2.setText(self._translate("MainWindow", "提交"))
            self.pushButton.setText(self._translate("MainWindow", "取消"))

            self.pushButton_2.clicked.connect(self.Submit_E)
            self.pushButton.clicked.connect(self.Cancel)

            self.label_2 = QtWidgets.QLabel(self.centralwidget)
            self.label_2.setObjectName("label_2")
            self.verticalLayout_2.addWidget(self.label_2)
            self.cur.execute( r"select * from tab_courses as a where a.cno in (select cno from tab_Score where sno='{}') ".format(self.Info[0]))
            Rows = self.cur.fetchall()
            Row = len(Rows)
            Vol = len(Rows[0]) - 1
            self.tableWidget_2 = QtWidgets.QTableWidget(self.centralwidget)
            self.tableWidget_2.setObjectName("tableWidget_2")

            self.tableWidget_2.setColumnCount(Vol)
            self.tableWidget_2.setRowCount(Row )
            item = QtWidgets.QTableWidgetItem()
            for i in range(Row):
                self.tableWidget_2.setVerticalHeaderItem(i, item)
                item = QtWidgets.QTableWidgetItem()
            for i in range(Vol):
                self.tableWidget_2.setHorizontalHeaderItem(i, item)
                item = QtWidgets.QTableWidgetItem()
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget_2.setItem(0, 0, item)
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget_2.setItem(1, 0, item)
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget_2.setItem(2, 1, item)
            self.verticalLayout_2.addWidget(self.tableWidget_2)
            #MainWindow.setCentralWidget(self.centralwidget)

            self.label_2.setText(self._translate("MainWindow", "已选课程"))

            for i in range(Row):
                item = self.tableWidget_2.verticalHeaderItem(i)
                item.setText(self._translate("MainWindow", "%d" % i))

            item = self.tableWidget_2.horizontalHeaderItem(0)
            item.setText(self._translate("MainWindow", "课程号"))
            item = self.tableWidget_2.horizontalHeaderItem(1)
            item.setText(self._translate("MainWindow", "课程名"))
            item = self.tableWidget_2.horizontalHeaderItem(2)
            item.setText(self._translate("MainWindow", "课程类型"))
            item = self.tableWidget_2.horizontalHeaderItem(3)
            item.setText(self._translate("MainWindow", "开课学期"))
            item = self.tableWidget_2.horizontalHeaderItem(4)
            item.setText(self._translate("MainWindow", "课程学分"))
            item = self.tableWidget_2.horizontalHeaderItem(5)
            item.setText(self._translate("MainWindow", "任课教师"))
            item = self.tableWidget_2.horizontalHeaderItem(6)
            item.setText(self._translate("MainWindow", "课程专业"))
            __sortingEnabled = self.tableWidget_2.isSortingEnabled()
            self.tableWidget_2.setSortingEnabled(False)
            for i in range(Row):
                for j in range(Vol):
                    print(Rows[i][j])
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget_2.setItem(i, j, item)
                    item = self.tableWidget_2.item(i, j)
                    item.setText(self._translate("MainWindow", str(Rows[i][j])))
            self.tableWidget.setSortingEnabled(__sortingEnabled)
    def Submit_E(self):
        self.Checkstate = []
        for i in range(self.tableWidget.rowCount()):
            if self.tableWidget.item(i, 8).checkState() == QtCore.Qt.Checked:
                CNO_TNO = (self.tableWidget.item(i, 0).text(), self.tableWidget.item(i, 5).text())
                self.Checkstate.append(CNO_TNO)
        print(self.Checkstate)
        for i in self.Checkstate:
            self.cur.execute(r"INSERT INTO tab_Score(sno,cno,tno,score) VALUES('{}','{}','{}',{})".format(self.Info[0], i[0], i[1], "NULL"))
            self.cur.execute(r"UPDATE tab_courses SET remain=remain-1 WHERE cno='{}'".format(i[0]))
            self.conn.commit()

        self.Elective()
    def Cancel(self):
        #取消
        for i in range(self.tableWidget.rowCount()):
            if self.tableWidget.item(i, 8).checkState() == QtCore.Qt.Checked:
                self.tableWidget.item(i, 8).setCheckState(QtCore.Qt.Unchecked)
    def Withdrawal(self):
        #退选
        try:
            self.tableWidget.deleteLater()
            self.tableWidget_2.deleteLater()
            self.label_2.deleteLater()
        except:
            print("666")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("666")
        finally:
            self.cur.execute(r"select * from tab_courses as a where a.cno in (select cno from tab_Score where sno='{}') ".format(self.Info[0]))
            Rows = self.cur.fetchall()
            Row = len(Rows)
            Vol = len(Rows[0])
            print(Rows)
            self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
            self.tableWidget.setObjectName("tableWidget")
            self.tableWidget.setColumnCount(Vol)
            self.tableWidget.setRowCount(Row)
            for i in range(Vol):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setVerticalHeaderItem(i, item)
            for i in range(Row+10):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setHorizontalHeaderItem(i, item)

            self.verticalLayout.addWidget(self.tableWidget)
            self.verticalLayout_2.addLayout(self.verticalLayout)
            self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
            self.pushButton_2.setObjectName("pushButton_2")
            self.verticalLayout_2.addWidget(self.pushButton_2)
            self.pushButton = QtWidgets.QPushButton(self.centralwidget)
            self.pushButton.setObjectName("pushButton")
            self.verticalLayout_2.addWidget(self.pushButton)
            self.label_2 = QtWidgets.QLabel(self.centralwidget)
            self.label_2.setObjectName("label_2")

            self._translate = QtCore.QCoreApplication.translate
            #MainWindow.setWindowTitle(self._translate("MainWindow", "MainWindow"))
            self.label_stduent_info.setText(self._translate("MainWindow", "网络工程(2018-2019)上学期16272411班级"))
            self.label.setText(self._translate("MainWindow", "可选课程"))
            item = self.tableWidget.horizontalHeaderItem(0)
            item.setText(self._translate("MainWindow", "课程号"))
            item = self.tableWidget.horizontalHeaderItem(1)
            item.setText(self._translate("MainWindow", "课程名"))
            item = self.tableWidget.horizontalHeaderItem(2)
            item.setText(self._translate("MainWindow", "课程类型"))
            item = self.tableWidget.horizontalHeaderItem(3)
            item.setText(self._translate("MainWindow", "开课学期"))
            item = self.tableWidget.horizontalHeaderItem(4)
            item.setText(self._translate("MainWindow", "课程学分"))
            item = self.tableWidget.horizontalHeaderItem(5)
            item.setText(self._translate("MainWindow", "任课教师"))
            item = self.tableWidget.horizontalHeaderItem(6)
            item.setText(self._translate("MainWindow", "课程专业"))
            item = self.tableWidget.horizontalHeaderItem(7)
            item.setText(self._translate("MainWindow", "退课"))
            __sortingEnabled = self.tableWidget.isSortingEnabled()
            self.tableWidget.setSortingEnabled(False)

            for i in range(Row):
                for j in range(Vol):
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget.setItem(i, j, item)
                    item = self.tableWidget.item(i, j)
                    if j == (Vol - 1):
                        cb = QtWidgets.QTableWidgetItem()
                        cb.setCheckState(QtCore.Qt.Unchecked)
                        self.tableWidget.setItem(i, j, cb)

                    else:
                        item.setText(self._translate("MainWindow", str(Rows[i][j])))

            self.tableWidget.setSortingEnabled(__sortingEnabled)
            self.pushButton_2.setText(self._translate("MainWindow", "提交"))
            self.pushButton.setText(self._translate("MainWindow", "取消"))
            self.pushButton_2.clicked.connect(self.Submit_draw)
            self.pushButton.clicked.connect(self.Cancel_draw)
    def Submit_draw(self):
        self.Checkstate = []
        for i in range(self.tableWidget.rowCount()):
            if self.tableWidget.item(i, 7).checkState() == QtCore.Qt.Checked:
                CNO_TNO = (self.tableWidget.item(i, 0).text(), self.tableWidget.item(i, 5).text())
                self.Checkstate.append(CNO_TNO)

        for i in self.Checkstate:
            self.cur.execute(r"DELETE FROM tab_Score WHERE sno='{}'and cno='{}'and tno='{}'".format(self.Info[0], i[0], i[1]))
            self.cur.execute(r"UPDATE tab_courses SET remain=remain+1 WHERE cno='{}'".format(i[0]))
            self.conn.commit()
        self.pushButton.deleteLater()
        self.pushButton_2.deleteLater()
        self.Withdrawal()
    def Cancel_draw(self):
        #取消
        for i in range(self.tableWidget.rowCount()):
            if self.tableWidget.item(i, 7).checkState() == QtCore.Qt.Checked:
                self.tableWidget.item(i, 7).setCheckState(QtCore.Qt.Unchecked)
    def Score_Query(self):
        try:
            self.tableWidget.deleteLater()
            self.tableWidget_2.deleteLater()
            self.label_2.deleteLater()
        except:
            print("666")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("666")
        finally:
            self.cur.execute(r"EXECUTE stu_history_score '{}',{}".format(self.Info[0],self.Info[1]))#查询历史成绩
            Rows = self.cur.fetchall()
            Row = len(Rows)
            Vol = len(Rows[0])
            print(Rows)
            self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
            self.tableWidget.setObjectName("tableWidget")
            self.tableWidget.setColumnCount(Vol)
            self.tableWidget.setRowCount(Row)
            for i in range(Vol):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setVerticalHeaderItem(i, item)
            for i in range(Row + 10):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setHorizontalHeaderItem(i, item)

            self.verticalLayout.addWidget(self.tableWidget)
            self.verticalLayout_2.addLayout(self.verticalLayout)
            self.label_2 = QtWidgets.QLabel(self.centralwidget)
            self.label_2.setObjectName("label_2")

            self._translate = QtCore.QCoreApplication.translate
            # MainWindow.setWindowTitle(self._translate("MainWindow", "MainWindow"))
            self.label_stduent_info.setText(self._translate("MainWindow", "网络工程(2018-2019)上学期16272411班级"))
            self.label.setText(self._translate("MainWindow", "本学期成绩记录"))
            item = self.tableWidget.horizontalHeaderItem(0)
            item.setText(self._translate("MainWindow", "学号"))
            item = self.tableWidget.horizontalHeaderItem(1)
            item.setText(self._translate("MainWindow", "姓名"))
            item = self.tableWidget.horizontalHeaderItem(2)
            item.setText(self._translate("MainWindow", "课程名"))
            item = self.tableWidget.horizontalHeaderItem(3)
            item.setText(self._translate("MainWindow", "课程成绩"))
            __sortingEnabled = self.tableWidget.isSortingEnabled()
            self.tableWidget.setSortingEnabled(False)

            for i in range(Row):
                for j in range(Vol):
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget.setItem(i, j, item)
                    item = self.tableWidget.item(i, j)
                    item.setText(self._translate("MainWindow", str(Rows[i][j])))
            self.tableWidget.setSortingEnabled(__sortingEnabled)
    def Score_history(self):
        try:
            self.tableWidget.deleteLater()
            self.tableWidget_2.deleteLater()
            self.label_2.deleteLater()
        except:
            print("666")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("666")
        finally:
            Rows=[]
            for i in range(self.Info[1]):
                self.cur.execute(r"EXECUTE stu_history_score '{}',{}".format(self.Info[0], i+1))  # 查询历史成绩
                Rows += self.cur.fetchall()
            Row = len(Rows)
            Vol = len(Rows[0])
            print(Rows)
            self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
            self.tableWidget.setObjectName("tableWidget")
            self.tableWidget.setColumnCount(Vol)
            self.tableWidget.setRowCount(Row)
            for i in range(Vol):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setVerticalHeaderItem(i, item)
            for i in range(Row + 10):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setHorizontalHeaderItem(i, item)

            self.verticalLayout.addWidget(self.tableWidget)
            self.verticalLayout_2.addLayout(self.verticalLayout)
            self.label_2 = QtWidgets.QLabel(self.centralwidget)
            self.label_2.setObjectName("label_2")

            self._translate = QtCore.QCoreApplication.translate
            # MainWindow.setWindowTitle(self._translate("MainWindow", "MainWindow"))
            self.label_stduent_info.setText(self._translate("MainWindow", "网络工程(2018-2019)上学期16272411班级"))
            self.label.setText(self._translate("MainWindow", "本学期成绩记录"))
            item = self.tableWidget.horizontalHeaderItem(0)
            item.setText(self._translate("MainWindow", "学号"))
            item = self.tableWidget.horizontalHeaderItem(1)
            item.setText(self._translate("MainWindow", "姓名"))
            item = self.tableWidget.horizontalHeaderItem(2)
            item.setText(self._translate("MainWindow", "课程名"))
            item = self.tableWidget.horizontalHeaderItem(3)
            item.setText(self._translate("MainWindow", "课程成绩"))
            __sortingEnabled = self.tableWidget.isSortingEnabled()
            self.tableWidget.setSortingEnabled(False)

            for i in range(Row):
                for j in range(Vol):
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget.setItem(i, j, item)
                    item = self.tableWidget.item(i, j)
                    item.setText(self._translate("MainWindow", str(Rows[i][j])))
            self.tableWidget.setSortingEnabled(__sortingEnabled)
    def GraduateDesign(self):
        reply = QtWidgets.QMessageBox.warning(self, "提示", "小伙纸，还没到选毕设课题的时间的！", QtWidgets.QMessageBox.NoButton)
    def Action7_slot(self):
        try:
            self.tableWidget.deleteLater()
            self.tableWidget_2.deleteLater()
            self.label_2.deleteLater()
        except:
            print("666")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("666")
        finally:
            self.cur.execute(r"execute stu_flunk  '{}',{}".format(self.Info[0],self.Info[1]))  # 查询历史成绩
            Rows = self.cur.fetchall()
            print(len(Rows))
            if len(Rows)==0:
                MessageBox=QtWidgets.QMessageBox.information(self,"提示","你没有不及格记录！",QtWidgets.QMessageBox.NoButton)
            else:
                Row = len(Rows)
                Vol = len(Rows[0])
                print(Rows)
                self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
                self.tableWidget.setObjectName("tableWidget")
                self.tableWidget.setColumnCount(Vol)
                self.tableWidget.setRowCount(Row)
                for i in range(Vol):
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget.setVerticalHeaderItem(i, item)
                for i in range(Row + 10):
                    item = QtWidgets.QTableWidgetItem()
                    self.tableWidget.setHorizontalHeaderItem(i, item)

                self.verticalLayout.addWidget(self.tableWidget)
                self.verticalLayout_2.addLayout(self.verticalLayout)
                self.label_2 = QtWidgets.QLabel(self.centralwidget)
                self.label_2.setObjectName("label_2")

                self._translate = QtCore.QCoreApplication.translate
                # MainWindow.setWindowTitle(self._translate("MainWindow", "MainWindow"))
                self.label_stduent_info.setText(self._translate("MainWindow", "网络工程(2018-2019)上学期16272411班级"))
                self.label.setText(self._translate("MainWindow", "本学期成绩记录"))
                item = self.tableWidget.horizontalHeaderItem(0)
                item.setText(self._translate("MainWindow", "课程号"))
                item = self.tableWidget.horizontalHeaderItem(1)
                item.setText(self._translate("MainWindow", "课程名"))
                item = self.tableWidget.horizontalHeaderItem(2)
                item.setText(self._translate("MainWindow", "任课教师"))
                item = self.tableWidget.horizontalHeaderItem(3)
                item.setText(self._translate("MainWindow", "考试成绩"))
                __sortingEnabled = self.tableWidget.isSortingEnabled()
                self.tableWidget.setSortingEnabled(False)

                for i in range(Row):
                    for j in range(Vol):
                        item = QtWidgets.QTableWidgetItem()
                        self.tableWidget.setItem(i, j, item)
                        item = self.tableWidget.item(i, j)
                        item.setText(self._translate("MainWindow", str(Rows[i][j])))
                self.tableWidget.setSortingEnabled(__sortingEnabled)
    def Action8_slot(self):
        try:
            self.tableWidget.deleteLater()
            self.tableWidget_2.deleteLater()
            self.label_2.deleteLater()
        except:
            print("666")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("666")
        finally:
            #MainWindow_Dialog=QtWidgets.QMainWindow
            self.ui=Password.Ui_Dialog(self.conn,self.Info)
            self.ui.show()
            #ui.setupUi(MainWindow_Dialog)



if __name__ == "__main__":
    conn = pymssql.connect(host='127.0.0.1', user='sa', password='19981111', database='StudentManage', charset='utf8')
    Info=("16010001",1,"123456")
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow(conn,Info,MainWindow)
    sys.exit(app.exec_())