# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Administrator.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import pymssql
import Password
class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self,MainWindow,conn,Info):
        super().__init__()
        self.cur = conn.cursor()
        self.conn = conn
        self.Info = Info
        self.setupUi(MainWindow)
        self.MainWindws = MainWindow
        MainWindow.setObjectName("Windows")
        MainWindow.setStyleSheet("#Windows{border-image:url(./image/lock.jpg);}")
        MainWindow.show()
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(648, 479)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 648, 26))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        self.menu_2 = QtWidgets.QMenu(self.menubar)
        self.menu_2.setObjectName("menu_2")
        self.menu_3 = QtWidgets.QMenu(self.menubar)
        self.menu_3.setObjectName("menu_3")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.action = QtWidgets.QAction(MainWindow)
        self.action.setObjectName("action")
        self.action_2 = QtWidgets.QAction(MainWindow)
        self.action_2.setObjectName("action_2")
        self.action_3 = QtWidgets.QAction(MainWindow)
        self.action_3.setObjectName("action_3")
        self.action_4 = QtWidgets.QAction(MainWindow)
        self.action_4.setObjectName("action_4")
        self.action_5 = QtWidgets.QAction(MainWindow)
        self.action_5.setObjectName("action_5")
        self.action_6 = QtWidgets.QAction(MainWindow)
        self.action_6.setObjectName("action_6")
        self.action_7 = QtWidgets.QAction(MainWindow)
        self.action_7.setObjectName("action_7")
        self.action_8 = QtWidgets.QAction(MainWindow)
        self.action_8.setObjectName("action_8")
        self.action_9 = QtWidgets.QAction(MainWindow)
        self.action_9.setObjectName("action_9")
        self.action_10 = QtWidgets.QAction(MainWindow)
        self.action_10.setObjectName("action_10")
        self.action_11=QtWidgets.QAction(MainWindow)
        self.action_11.setObjectName("action_11")
        self.action_12 = QtWidgets.QAction(MainWindow)
        self.action_12.setObjectName("action_11")
        self.menu.addAction(self.action)
        self.menu.addAction(self.action_2)
        self.menu.addAction(self.action_3)
        self.menu.addAction(self.action_4)
        self.menu.addAction(self.action_5)
        self.menu_2.addAction(self.action_6)
        self.menu_2.addAction(self.action_7)
        self.menu_2.addAction(self.action_8)
        self.menu_3.addAction(self.action_9)
        self.menu_3.addAction(self.action_10)
        self.menu_3.addAction(self.action_11)
        self.menu_2.addAction(self.action_12)
        self.menubar.addAction(self.menu.menuAction())
        self.menubar.addAction(self.menu_2.menuAction())
        self.menubar.addAction(self.menu_3.menuAction())

        self.retranslateUi(MainWindow)
        self.action.triggered.connect(self.action_slot)
        self.action_2.triggered.connect(self.action2_slot)
        self.action_3.triggered.connect(self.action3_slot)
        self.action_4.triggered.connect(self.Account_remove_slot)
        self.action_6.triggered.connect(self.Info_teacher)
        self.action_7.triggered.connect(self.Info_student)
        self.action_8.triggered.connect(self.Info_course)
        self.action_9.triggered.connect(self.Info_Score)
        self.action_10.triggered.connect(self.Course_edit)
        self.action_11.triggered.connect(self.PasswdChange_slot)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "管理员"))

        self.menu.setTitle(_translate("MainWindow", "账户管理"))
        self.menu_2.setTitle(_translate("MainWindow", "课程管理"))
        self.menu_3.setTitle(_translate("MainWindow", "成绩统计"))
        self.action.setText(_translate("MainWindow", "教师账户"))
        self.action_2.setText(_translate("MainWindow", "学生账户"))
        self.action_3.setText(_translate("MainWindow", "账户添加"))
        self.action_4.setText(_translate("MainWindow", "账户移除"))
        self.action_5.setText(_translate("MainWindow", "管理员添加"))
        self.action_6.setText(_translate("MainWindow", "教师资料"))
        self.action_7.setText(_translate("MainWindow", "学生资料"))
        self.action_8.setText(_translate("MainWindow", "课程资料"))
        self.action_9.setText(_translate("MainWindow", "课程成绩"))
        self.action_10.setText(_translate("MainWindow", "课程修改"))
        self.action_11.setText(_translate("MainWindow","密码修改"))
        self.action_12.setText((_translate("Mainwidow","成绩查询")))
    def action3_slot(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(10)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(3):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "账户"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "密码"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "身份"))
        self.pushButton.setText(_translate("MainWindow", "确认"))
        self.pushButton_2.setText(_translate("MainWindow", "取消"))
        self.pushButton.clicked.connect(self.submit_add)

    def action_slot(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from tab_account where id='教师'")
        StudentInfo = self.cur.fetchall()
        print(StudentInfo)
        self.Row = len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(3):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "账户"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "密码"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "身份"))
        self.pushButton.setText(_translate("MainWindow", "确认"))
        self.pushButton_2.setText(_translate("MainWindow", "取消"))
        self.pushButton.clicked.connect(self.submit_Account)

        for i in range(self.Row):
            for j in range(3):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", StudentInfo[i][j].strip()))
        for i in range(self.Row):
            self.tableWidget.item(i, 0).setFlags(QtCore.Qt.ItemIsEnabled)
    def action_admin_slot(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from tab_account where id='管理员'")
        StudentInfo = self.cur.fetchall()
        print(StudentInfo)
        self.Row = len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(3):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)
            print(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "账户"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "密码"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "身份"))
        self.pushButton.setText(_translate("MainWindow", "确认"))
        self.pushButton_2.setText(_translate("MainWindow", "取消"))

        self.pushButton.clicked.connect(self.submit_Account)

        for i in range(self.Row):
            for j in range(3):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", StudentInfo[i][j].strip()))
        print("Ok??")
        for i in range(self.Row):
            self.tableWidget.item(i, 0).setFlags(QtCore.Qt.ItemIsEnabled)
    def action2_slot(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from tab_account where id='学生'")
        StudentInfo=self.cur.fetchall()
        print(StudentInfo)
        self.Row=len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        print("fine")
        for i in range(3):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)

            item.setText(_translate("MainWindow", "%d"%i))
        print("there")
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "账户"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "密码"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "身份"))
        self.pushButton.setText(_translate("MainWindow", "确认"))
        self.pushButton_2.setText(_translate("MainWindow", "取消"))
        print("are")

        self.pushButton.clicked.connect(self.submit_Account)

        for i in range(self.Row):
            for j in range(3):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow",StudentInfo[i][j]))
        print("Ok??")
        for i in range(self.Row):
            self.tableWidget.item(i, 0).setFlags(QtCore.Qt.ItemIsEnabled)
    def submit_Account(self):
        Change=[]
        for i in range(self.Row):
            item = []
            for j in range(3):
                item.append(self.tableWidget.item(i,j).text())
            Change.append(item)
        print(Change)
        for i in Change:
            self.cur.execute("update tab_account set passwd='{}',id='{}' where admin='{}'".format(i[1],i[2].strip(),i[0]))
            self.conn.commit()
        Tips=QtWidgets.QMessageBox.information(self,"提示","信息已保存!",QtWidgets.QMessageBox.Yes)
    def submit_add(self):
        Change = []
        for i in range(10):
            item=[]
            try:
                if len(self.tableWidget.item(i, 0).text()):
                    print(i)
                    for j in range(3):
                        item.append(self.tableWidget.item(i, j).text())
                    Change.append(item)
            except:
                pass
        print(Change)
        for i in Change:
            if i[2]=="管理员":
                Tips = QtWidgets.QMessageBox.warning(self, "提示", "无添加管理员操作权限", QtWidgets.QMessageBox.Yes)
            self.cur.execute(r"INSERT INTO tab_account(admin,passwd,id) VALUES('{}','{}','{}')".format(i[0],i[1],i[2]))
            self.conn.commit()
    def Account_remove_slot(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from tab_account where id='学生' or id= '教师'")
        StudentInfo=self.cur.fetchall()
        print(StudentInfo)
        self.Row=len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(4):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)

            item.setText(_translate("MainWindow", "%d"%i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "账户"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "密码"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "身份"))
        self.pushButton.setText(_translate("MainWindow", "确认"))
        self.pushButton_2.setText(_translate("MainWindow", "取消"))
        self.pushButton.clicked.connect(self.Submit_Remove)
        self.pushButton_2.clicked.connect(self.Remove_Cancel)

        for i in range(self.Row):
            for j in range(4):
                print(i,j)
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                if j==3:
                    cb = QtWidgets.QTableWidgetItem()
                    cb.setCheckState(QtCore.Qt.Unchecked)
                    self.tableWidget.setItem(i, j, cb)
                else:
                    item.setText(_translate("MainWindow",StudentInfo[i][j]))
        for i in range(self.Row):
            for j in range(3):
             self.tableWidget.item(i, j).setFlags(QtCore.Qt.ItemIsEnabled)
    def Submit_Remove(self):
        CheckState=[]
        for i in range(self.Row):
            if self.tableWidget.item(i,3).checkState() == QtCore.Qt.Checked:
                CheckState.append(self.tableWidget.item(i,0).text())
        for i in CheckState:
            print(r"delete from tab_account where admin='{}'".format(i))
            self.cur.execute(r"delete from tab_account where admin='{}'".format(i))
            self.conn.commit()
        Tips = QtWidgets.QMessageBox.information(self, "提示", "删除成功", QtWidgets.QMessageBox.Yes)
        self.Account_remove_slot()
    def Remove_Cancel(self):
        for i in range(self.Row):
            self.tableWidget.item(i,3).setCheckState(QtCore.Qt.Unchecked)

    def Info_student(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from View_Student where instno='{}'".format(self.Info[0]))
        StudentInfo = self.cur.fetchall()
        print(StudentInfo)
        self.Row = len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(13)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(13):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "学号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "姓名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "性别"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "生日"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "年级"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "辅导员"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "邮箱"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "状态"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "专业号"))
        item = self.tableWidget.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "专业名称"))
        item = self.tableWidget.horizontalHeaderItem(10)
        item.setText(_translate("MainWindow", "学院号"))
        item = self.tableWidget.horizontalHeaderItem(11)
        item.setText(_translate("MainWindow", "学院名称"))
        item = self.tableWidget.horizontalHeaderItem(12)
        item.setText(_translate("MainWindow", "院长"))
        for i in range(self.Row):
            for j in range(13):
                print(i,j)
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(StudentInfo[i][j]).strip()))
    def Info_teacher(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from View_Teacher where instno='{}'".format(self.Info[0]))
        StudentInfo = self.cur.fetchall()
        print(StudentInfo)
        self.Row = len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(9)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(9):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "教师工号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "教师姓名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "邮箱"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "性别"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "职称"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "学院号"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "学院名称"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "地址"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "院长"))
        for i in range(self.Row):
            for j in range(9):
                print(i, j)
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(StudentInfo[i][j]).strip()))
    def Info_course(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from View_Course where instno= '{}'".format(self.Info[0]))
        StudentInfo = self.cur.fetchall()
        print(StudentInfo)
        self.Row = len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(9)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(9):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "课程学分"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "开课学期"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "任课教师号"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "任课教师名"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程余量"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "开课学院"))
        for i in range(self.Row):
            for j in range(9):
                print(i, j)
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(StudentInfo[i][j]).strip()))


    def Info_Score(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.cur.execute(r"select * from View_Score where instno= '{}'and score >0".format(self.Info[0]))
        StudentInfo = self.cur.fetchall()
        self.Row = len(StudentInfo)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(10)
        self.tableWidget.setRowCount(self.Row)
        for i in range(self.Row):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(10):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        self.verticalLayout.addWidget(self.tableWidget)
        _translate = QtCore.QCoreApplication.translate
        for i in range(self.Row):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "学号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "姓名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "任课教师号"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师姓名"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "课程学期"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "开课学院"))
        item = self.tableWidget.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "成绩"))
        for i in range(self.Row):
            for j in range(10):
                print(i, j)
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(StudentInfo[i][j]).strip()))
    def PasswdChange_slot(self):
        self.ui = Password.Ui_Dialog(self.conn, self.Info)
        self.ui.show()
    def Course_edit(self):
        try:
            self.tableWidget.deleteLater()
        except:
            print("233")
        try:
            self.pushButton.deleteLater()
            self.pushButton_2.deleteLater()
        except:
            print("233")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName("tableWidget")
        self.cur.execute(r"select * from tab_courses where tno in (select tno from tab_teacher where instno='{}') ".format(self.Info[0]))
        Courserecord = self.cur.fetchall()
        self.row_R = len(Courserecord)
        self.tableWidget.setColumnCount(8)
        self.tableWidget.setRowCount(self.row_R )
        for i in range(self.row_R ):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(8):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)

        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)

        _translate = QtCore.QCoreApplication.translate
        for i in range(self.row_R):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("MainWindow", "%d" % i))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "课程号"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "课程名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "课程类型"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "开课学期"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "课程学分"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "教师号"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "专业号"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "课程容量"))
        for i in range(self.row_R):
            for j in range(8):
                item = QtWidgets.QTableWidgetItem()
                self.tableWidget.setItem(i, j, item)
                item = self.tableWidget.item(i, j)
                item.setText(_translate("MainWindow", str(Courserecord[i][j])))
        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.pushButton_2.setText(_translate("MainWindow", "提交"))
        self.pushButton.setText(_translate("MainWindow", "取消"))
        self.pushButton_2.clicked.connect(self.Course_chage)
        print(self.row_R)
        for i in range(self.row_R):
            print(i)
            self.tableWidget.item(i, 0).setFlags(QtCore.Qt.ItemIsEnabled)

    def Course_chage(self):
        self._translate = QtCore.QCoreApplication.translate
        Col_Count = self.tableWidget.columnCount()
        Row_Count = self.tableWidget.rowCount()
        print(Col_Count, Row_Count)
        CoreseC = []
        for i in range(Row_Count):
            Cour_data = []
            if self.tableWidget.item(i, 0).text():
                print(i)
                print((self.tableWidget.item(i, 0).text()) == None)
                for j in range(Col_Count):
                    print(j)
                    Cour_data.append(self.tableWidget.item(i, j).text())
                CoreseC.append(Cour_data)

            else:
                continue
        flag = 0  # 记录是否触发警告
        for i in CoreseC:
            if int(i[3]) < 1 or int(i[3]) > 8 :
                tips = QtWidgets.QMessageBox.warning(self, "提示", "学期不正确", QtWidgets.QMessageBox.NoButton)
                flag = 1
                print(i)
            elif int(i[4]) < 0.5 or int(i[4]) > 5:
                tips = QtWidgets.QMessageBox.warning(self, "提示", "学分不正确", QtWidgets.QMessageBox.NoButton)
                flag = 1
                print(i)
            elif i[0] == "":
                tips = QtWidgets.QMessageBox.warning(self, "提示", "课程号不可空", QtWidgets.QMessageBox.NoButton)
                flag = 1
            else:

                self.cur.execute(r"update tab_courses set cname='{}',ctype='{}',term={},credit={},tno='{}',majorno='{}',remain={} where cno='{}'".format(i[1],i[2],i[3],i[4],i[5],i[6].strip(),i[7],i[0]))
                self.conn.commit()
        if not flag:
            tips = QtWidgets.QMessageBox.information(self, "提示", "修改成功", QtWidgets.QMessageBox.NoButton)
            self.Course_edit()


if __name__=='__main__':
    conn = pymssql.connect(host='127.0.0.1', user='sa', password='19981111', database='StudentManage', charset='utf8')
    Info = ("XY01", "管理员","XY01")
    App=QtWidgets.QApplication(sys.argv)
    MainWindow=QtWidgets.QMainWindow()
    Ui=Ui_MainWindow(MainWindow,conn,Info)
    App.exec_()