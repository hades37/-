# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'password.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import pymssql
class Ui_Dialog(QtWidgets.QDialog):
    def __init__(self,conn,Info):
        super().__init__()
        self.setupUi(self)
        self.conn=conn
        self.Info=Info
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(640, 480)
        self.buttonBox = QtWidgets.QDialogButtonBox(Dialog)
        self.buttonBox.setGeometry(QtCore.QRect(10, 360, 621, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayoutWidget = QtWidgets.QWidget(Dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(160, 110, 361, 191))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.lineEdit_Old = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_Old.setObjectName("lineEdit_Old")
        self.verticalLayout.addWidget(self.lineEdit_Old)
        self.lineEdit_New = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_New.setObjectName("lineEdit_New")
        self.verticalLayout.addWidget(self.lineEdit_New)
        self.lineEdit_New2 = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_New2.setObjectName("lineEdit_New2")
        self.verticalLayout.addWidget(self.lineEdit_New2)
        self.verticalLayoutWidget_2 = QtWidgets.QWidget(Dialog)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(0, 110, 160, 191))
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.labelOld = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.labelOld.setObjectName("labelOld")
        self.verticalLayout_2.addWidget(self.labelOld)
        self.label_New = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_New.setObjectName("label_New")
        self.verticalLayout_2.addWidget(self.label_New)
        self.label_New2 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_New2.setObjectName("label_New2")
        self.verticalLayout_2.addWidget(self.label_New2)

        self.retranslateUi(Dialog)
        self.buttonBox.accepted.connect(self.Submit_slot)
        self.buttonBox.rejected.connect(self.Cancel_slot)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
    def Submit_slot(self):
        old_Passwd=self.lineEdit_Old.text()
        if old_Passwd.strip()!=self.Info[2]:
            tips=QtWidgets.QMessageBox.warning(self,"提示","原密码错误!",QtWidgets.QMessageBox.NoButton)
        else:
            New_Passwd=self.lineEdit_New.text()
            New2_Passwd=self.lineEdit_New2.text()
            if New2_Passwd.strip()!=New_Passwd.strip():
                tips=tips=QtWidgets.QMessageBox.warning(self,"提示","前后密码不一致!",QtWidgets.QMessageBox.NoButton)
            else:
                self.Cur = self.conn.cursor()

                self.Cur.execute(r"UPDATE tab_account SET passwd='{}' WHERE admin='{}'".format(New_Passwd,self.Info[0]))
                self.conn.commit()
                tips=QtWidgets.QMessageBox.information(self,"提示","修改成功！",QtWidgets.QMessageBox.NoButton)
                self.lineEdit_Old.clear()
                self.lineEdit_New2.clear()
                self.lineEdit_New.clear()
    def Cancel_slot(self):
        self.lineEdit_Old.clear()
        self.lineEdit_New2.clear()
        self.lineEdit_New.clear()

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "密码修改"))
        self.labelOld.setText(_translate("Dialog", "       旧密码"))
        self.label_New.setText(_translate("Dialog", "       新密码"))
        self.label_New2.setText(_translate("Dialog", "       新密码"))
if __name__=='__main__':
    App=QtWidgets.QApplication(sys.argv)
    Dialog=Ui_Dialog()
    Dialog.show()
    sys.exit(App.exec_())